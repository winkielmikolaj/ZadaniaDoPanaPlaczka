﻿using System;

namespace Kalkulator
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Kalkulator");
            Console.WriteLine("Dostępne operacje:");
            Console.WriteLine("1 - Dodawanie");
            Console.WriteLine("2 - Odejmowanie");
            Console.WriteLine("3 - Mnożenie");
            Console.WriteLine("4 - Dzielenie");
            Console.WriteLine("5 - Potęgowanie");
            Console.WriteLine("6 - Pierwiastkowanie");

            while (true)
            {
                try
                {
                    Console.Write("Wybierz operację (1-6): ");
                    int wybor = int.Parse(Console.ReadLine());

                    if (wybor < 1 || wybor > 6)
                        throw new InvalidOperationException("Nieprawidłowy wybór operacji.");

                    Console.Write("Podaj pierwszą liczbę: ");
                    double liczba1 = double.Parse(Console.ReadLine());

                    double wynik;

                    if (wybor == 6)
                    {
                        wynik = Pierwiastkowanie(liczba1);
                    }
                    else
                    {
                        Console.Write("Podaj drugą liczbę: ");
                        double liczba2 = double.Parse(Console.ReadLine());

                        wynik = wybor switch
                        {
                            1 => Dodawanie(liczba1, liczba2),
                            2 => Odejmowanie(liczba1, liczba2),
                            3 => Mnozenie(liczba1, liczba2),
                            4 => Dzielenie(liczba1, liczba2),
                            5 => Potegowanie(liczba1, liczba2),
                            _ => throw new InvalidOperationException("Nieprawidłowy wybór operacji.")
                        };
                    }

                    Console.WriteLine($"Wynik: {Math.Round(wynik, 2)}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Błąd: {ex.Message}");
                }

                Console.WriteLine("Czy chcesz wykonać kolejne działanie? (tak/nie)");
                if (Console.ReadLine()?.ToLower() != "tak") break;
            }
        }

        static double Dodawanie(double a, double b) => a + b;

        static double Odejmowanie(double a, double b) => a - b;

        static double Mnozenie(double a, double b) => a * b;

        static double Dzielenie(double a, double b)
        {
            if (b == 0)
                throw new DivideByZeroException("Nie można dzielić przez zero.");
            return a / b;
        }

        static double Potegowanie(double a, double b) => Math.Pow(a, b);

        static double Pierwiastkowanie(double a)
        {
            if (a < 0)
                // dla uproszczenia
                throw new ArgumentException("Nie można obliczyć pierwiastka z liczby ujemnej.");
            return Math.Sqrt(a);
        }
    }
}
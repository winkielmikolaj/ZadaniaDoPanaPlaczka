namespace KalkulatorTestyJednostkowe
{
    public class KalkulatorTests
    {
        [Theory]
        [InlineData(1, 3, 5, 8)]
        [InlineData(2, 10, 7, 3)]
        [InlineData(3, 4, 2, 8)]
        [InlineData(4, 10, 2, 5)]
        [InlineData(5, 2, 3, 8)]
        public void Test_Operacje_Podstawowe(int wybor, double liczba1, double liczba2, double oczekiwanyWynik)
        {
            double wynik = wybor switch
            {
                1 => Dodawanie(liczba1, liczba2),
                2 => Odejmowanie(liczba1, liczba2),
                3 => Mnozenie(liczba1, liczba2),
                4 => Dzielenie(liczba1, liczba2),
                5 => Potegowanie(liczba1, liczba2),
                _ => throw new InvalidOperationException("Nieprawid�owy wyb�r operacji.")
            };

            Assert.Equal(oczekiwanyWynik, Math.Round(wynik, 2));
        }

        [Fact]
        public void Test_Pierwiastkowanie()
        {
            double liczba = 9;

            double wynik = Pierwiastkowanie(liczba);

            Assert.Equal(3, wynik, 2);
        }

        [Fact]
        public void Test_Dzielenie_Przez_Zero()
        {
            double liczba1 = 10;
            double liczba2 = 0;

            Assert.Throws<DivideByZeroException>(() => Dzielenie(liczba1, liczba2));
        }

        [Fact]
        public void Test_Nieprawidlowy_Wybor_Operacji()
        {
            int wybor = 7;
            double liczba1 = 10;
            double liczba2 = 5;

            Assert.Throws<InvalidOperationException>(() => wybor switch
            {
                1 => Dodawanie(liczba1, liczba2),
                2 => Odejmowanie(liczba1, liczba2),
                3 => Mnozenie(liczba1, liczba2),
                4 => Dzielenie(liczba1, liczba2),
                5 => Potegowanie(liczba1, liczba2),
                6 => Pierwiastkowanie(liczba1),
                _ => throw new InvalidOperationException("Nieprawid�owy wyb�r operacji.")
            });
        }

        private double Dodawanie(double a, double b) => a + b;

        private double Odejmowanie(double a, double b) => a - b;

        private double Mnozenie(double a, double b) => a * b;

        private double Dzielenie(double a, double b)
        {
            if (b == 0)
                throw new DivideByZeroException("Nie mo�na dzieli� przez zero.");
            return a / b;
        }

        private double Potegowanie(double a, double b) => Math.Pow(a, b);

        private double Pierwiastkowanie(double a)
        {
            if (a < 0)
                throw new ArgumentException("Nie mo�na obliczy� pierwiastka z liczby ujemnej.");
            return Math.Sqrt(a);
        }
    }
}